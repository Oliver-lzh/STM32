# FIXED

dss_pca_vitalsigns.oe674: ../dss_pca_vitalsigns.c
dss_pca_vitalsigns.oe674: ../dss_pca_vitalsigns.h
dss_pca_vitalsigns.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/math.h
dss_pca_vitalsigns.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/linkage.h
dss_pca_vitalsigns.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/elfnames.h
dss_pca_vitalsigns.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/mathf.h
dss_pca_vitalsigns.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/mathl.h
dss_pca_vitalsigns.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/string.h

../dss_pca_vitalsigns.c:

../dss_pca_vitalsigns.h:

C:/ti/ti-cgt-c6000_8.1.3/include/math.h:

C:/ti/ti-cgt-c6000_8.1.3/include/linkage.h:

C:/ti/ti-cgt-c6000_8.1.3/include/elfnames.h:

C:/ti/ti-cgt-c6000_8.1.3/include/mathf.h:

C:/ti/ti-cgt-c6000_8.1.3/include/mathl.h:

C:/ti/ti-cgt-c6000_8.1.3/include/string.h:

