# FIXED

dss_vitalSignsDemo_utilsFunc.oe674: ../dss_vitalSignsDemo_utilsFunc.c
dss_vitalSignsDemo_utilsFunc.oe674: ../dss_vitalSignsDemo_utilsFunc.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/stdint.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/mmwave_sdk_02_00_00_04/packages/ti/common/sys_common.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/stdbool.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/mmwave_sdk_02_00_00_04/packages/ti/common/sys_common_xwr16xx.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/mmwave_sdk_02_00_00_04/packages/ti/common/sys_common_xwr16xx_dss.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/stdlib.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/linkage.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/stddef.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/string.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/stdio.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/stdarg.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/math.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/elfnames.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/mathf.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/mathl.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/std.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/stdarg.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/ti-cgt-c6000_8.1.3/include/stddef.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/bios_6_53_02_00/packages/ti/targets/elf/std.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/bios_6_53_02_00/packages/ti/targets/elf/C674.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/bios_6_53_02_00/packages/ti/targets/std.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/cfg/global.h
dss_vitalSignsDemo_utilsFunc.oe674: configPkg/package/cfg/dss_mmw_pe674.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/bios_6_53_02_00/packages/ti/sysbios/heaps/HeapMem.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/xdc.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types__prologue.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/package/package.defs.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types__epilogue.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/bios_6_53_02_00/packages/ti/sysbios/heaps/package/package.defs.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Memory.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IHeap.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error__prologue.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Main.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IGateProvider.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/package/Main_Module_GateProxy.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IGateProvider.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error__epilogue.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Memory.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IHeap.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/package/Memory_HeapProxy.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IHeap.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IHeap.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Assert.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Assert__prologue.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Main.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Diags.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Diags__prologue.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Main.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Diags__epilogue.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Diags.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Assert__epilogue.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IGateProvider.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/bios_6_53_02_00/packages/ti/sysbios/heaps/package/HeapMem_Module_GateProxy.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IGateProvider.h
dss_vitalSignsDemo_utilsFunc.oe674: C:/ti/bios_6_53_02_00/packages/ti/sysbios/heaps/package/HeapMem_Module_GateProxy.h

../dss_vitalSignsDemo_utilsFunc.c:

../dss_vitalSignsDemo_utilsFunc.h:

C:/ti/ti-cgt-c6000_8.1.3/include/stdint.h:

C:/ti/mmwave_sdk_02_00_00_04/packages/ti/common/sys_common.h:

C:/ti/ti-cgt-c6000_8.1.3/include/stdbool.h:

C:/ti/mmwave_sdk_02_00_00_04/packages/ti/common/sys_common_xwr16xx.h:

C:/ti/mmwave_sdk_02_00_00_04/packages/ti/common/sys_common_xwr16xx_dss.h:

C:/ti/ti-cgt-c6000_8.1.3/include/stdlib.h:

C:/ti/ti-cgt-c6000_8.1.3/include/linkage.h:

C:/ti/ti-cgt-c6000_8.1.3/include/stddef.h:

C:/ti/ti-cgt-c6000_8.1.3/include/string.h:

C:/ti/ti-cgt-c6000_8.1.3/include/stdio.h:

C:/ti/ti-cgt-c6000_8.1.3/include/stdarg.h:

C:/ti/ti-cgt-c6000_8.1.3/include/math.h:

C:/ti/ti-cgt-c6000_8.1.3/include/elfnames.h:

C:/ti/ti-cgt-c6000_8.1.3/include/mathf.h:

C:/ti/ti-cgt-c6000_8.1.3/include/mathl.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/std.h:

C:/ti/ti-cgt-c6000_8.1.3/include/stdarg.h:

C:/ti/ti-cgt-c6000_8.1.3/include/stddef.h:

C:/ti/bios_6_53_02_00/packages/ti/targets/elf/std.h:

C:/ti/bios_6_53_02_00/packages/ti/targets/elf/C674.h:

C:/ti/bios_6_53_02_00/packages/ti/targets/std.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/cfg/global.h:

configPkg/package/cfg/dss_mmw_pe674.h:

C:/ti/bios_6_53_02_00/packages/ti/sysbios/heaps/HeapMem.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/xdc.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types__prologue.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/package/package.defs.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types__epilogue.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/bios_6_53_02_00/packages/ti/sysbios/heaps/package/package.defs.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Memory.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IHeap.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error__prologue.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Main.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IGateProvider.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/package/Main_Module_GateProxy.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IGateProvider.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error__epilogue.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Memory.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IHeap.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/package/Memory_HeapProxy.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IHeap.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IHeap.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Assert.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Assert__prologue.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Main.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Diags__prologue.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Main.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Diags__epilogue.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IModule.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Diags.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Error.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Assert__epilogue.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IGateProvider.h:

C:/ti/bios_6_53_02_00/packages/ti/sysbios/heaps/package/HeapMem_Module_GateProxy.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/Types.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IInstance.h:

C:/ti/xdctools_3_50_04_43_core/packages/xdc/runtime/IGateProvider.h:

C:/ti/bios_6_53_02_00/packages/ti/sysbios/heaps/package/HeapMem_Module_GateProxy.h:

